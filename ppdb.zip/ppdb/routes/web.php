<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});


Route::get('/siswa', '\App\Http\Controllers\SiswaController@index')->name('siswa.index');
Route::get('/siswa/create', '\App\Http\Controllers\SiswaController@create')->name('siswa.create');
Route::post('/siswa/create', '\App\Http\Controllers\SiswaController@store')->name('siswa.store');
Route::get('siswa/edit/{id}', '\App\Http\Controllers\SiswaController@edit')->name('siswa.edit');
Route::post('siswa/update/{id}', '\App\Http\Controllers\SiswaController@update')->name('siswa.update');
Route::get('siswa/delete/{id}', '\App\Http\Controllers\SiswaController@destroy')->name('siswa.destroy');
Route::get('siswa/show/{id}', '\App\Http\Controllers\SiswaController@show')->name('siswa.show');
Route::get('siswa/clear', '\App\Http\Controllers\SiswaController@clear')->name('siswa.clear');