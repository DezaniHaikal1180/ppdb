<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tabel;

class TabelController extends Controller
{
    public function index()
    {
       $data = Tabel::orderBy('created_at', 'DESC')->get();
       return view('tabel.index', compact('data'));
    }
    public function create()
    {
        $tabel = Tabel::al();
        return view('tabel.create', compact('tabel'));	
    }
    public function store(Request $request)
    {
    	$this->validate($request, [
            'nis' => 'required|string',
            'nama' => 'required',
            'jns_kelamin' => 'required',
            'temp_lahir' => 'required',
            'tgl_lahir' => 'required',
            'alamat' => 'required',
            'asal_sekolah' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
        ]);
        Tabel::create([
            'nis' => $request->nis,
            'nama' => $request->nama,
            'jns_kelamin' => $request->jns_kelamin,
            'temp_lahir' => $request->temp_lahir,
            'tgl_lahir' => $request->tgl_lahir,
            'alamat' => $request->alamat,
            'asal_sekolah' => $request->asal_sekolah,
            'kelas' => $request->kelas,
            'jurusan' => $request->jurusan,
        ]);
        return redirct()->route('tabel.index')->with('success', 'Data Berhasil ditambah')
    }
    public function show($id)
    {
    	$data = Tabel::findOrFail($id);
        return view('tabel.show', compact('data'));
    }
    public function edit($id)
    {
    	$data = Tabel::findOrFail($id);
        return view('tabel.show', compact('data'));
    }
    public function update(Request $request, $id)
    {
    	$this->validate($request, [
            'nis' => 'required|string',
            'nama' => 'required',
            'jns_kelamin' => 'required',
            'temp_lahir' => 'required',
            'tgl_lahir' => 'required',
            'alamat' => 'required',
            'asal_sekolah' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
        ]);
        $data = Tabel::findOrFail($id);
        $data->update($request->all());
        return redirct()->route('tabel.update')->with('success','Data Berhasil diupdate');
    }
    public function destroy($id)
    {
    	$data = Tabel::findOrFail($id);
        $data->delete();
        return back()->with('success', 'Data Berhasil Didelete');
    }
    public function clear(Request $request)
    {
    	$data = Tabel::all();
        $data->delete();
        return back()->with('success', 'Data Berhasil Didelete');
    }
}
