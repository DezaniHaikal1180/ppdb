<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa;

class SiswaController extends Controller
{
    public function index()
    {
       $data = Siswa::orderBy('created_at', 'DESC')->get();
       return view('siswa.index', compact('data'));
    }
    public function create()
    {
        $siswa = Siswa::all();
        return view('siswa.create', compact('siswa'));	
    }
    public function store(Request $request)
    {
    	$this->validate($request, [
            'nis' => 'required|string',
            'nama' => 'required',
            'jns_kelamin' => 'required',
            'temp_lahir' => 'required',
            'tgl_lahir' => 'required',
            'alamat' => 'required',
            'asal_sekolah' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
        ]);
        Siswa::create([
            'nis' => $request->nis,
            'nama' => $request->nama,
            'jns_kelamin' => $request->jns_kelamin,
            'temp_lahir' => $request->temp_lahir,
            'tgl_lahir' => $request->tgl_lahir,
            'alamat' => $request->alamat,
            'asal_sekolah' => $request->asal_sekolah,
            'kelas' => $request->kelas,
            'jurusan' => $request->jurusan,
        ]);
        return back()->with('success', 'Data Berhasil ditambah');
    }
    public function show($id)
    {
    	$data = Siswa::findOrFail($id);
        return view('siswa.show', compact('data'));
    }
    public function edit($id)
    {
    	$data = Siswa::findOrFail($id);
        return view('siswa.edit', compact('data'));
    }
    public function update(Request $request, $id)
    {
    	$this->validate($request, [
            'nis' => 'required|string',
            'nama' => 'required',
            'jns_kelamin' => 'required',
            'temp_lahir' => 'required',
            'tgl_lahir' => 'required',
            'alamat' => 'required',
            'asal_sekolah' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
        ]);
        $data = Siswa::findOrFail($id);
        $data->update($request->all());
        return back()->with('success','Data Berhasil diupdate');
    }
    public function destroy($id)
    {
    	$data = Siswa::findOrFail($id);
        $data->delete();
        return back()->with('success', 'Data Berhasil Didelete');
    }
    public function clear(Request $request)
    {
    	$data = Siswa::all();
        $data->delete($request->all());
        return back()->with('success', 'Data Berhasil Didelete');
    }
}
