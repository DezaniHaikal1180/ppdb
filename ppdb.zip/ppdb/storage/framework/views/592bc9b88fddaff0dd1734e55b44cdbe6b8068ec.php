<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="row">
		<div class="col-lg-12">
			<div class="card">
				<div class="card-header">
					<div class="pull-rigth">
						<a class="btn btn-primary" href="<?php echo e(route('tabel.index')); ?>">Add</a>
					</div>
				</div>
				<?php if($message = Session::get('success')): ?>
					<div class="alert alert-success">
						<p><?php echo e(message); ?></p>
					</div>
				<?php endif; ?>
				<div class="card-body">
					<table class="table">
						<thead>
							<tr>
								<th class="col">nis</th>
								<th class="col">nama</th>
								<th class="col">jns kelamin</th>
								<th class="col">temp lahir</th>
								<th class="col">tgl lahir</th>
								<th class="col">alamat</th>
								<th class="col">asal sekolah</th>
								<th class="col">kelas</th>
								<th class="col">jurusan</th>
							</tr>
						</thead>
					<tbody>
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($tabel->nis); ?></td>
							<td><?php echo e($tabel->nama); ?></td>
							<td><?php echo e($tabel->jns_kelamin); ?></td>
							<td><?php echo e($tabel->temp_lahir); ?></td>
							<td><?php echo e($tabel->tgl_lahir); ?></td>
							<td><?php echo e($tabel->alamat); ?></td>
							<td><?php echo e($tabel->asal_sekolah); ?></td>
							<td><?php echo e($tabel->kelas); ?></td>
							<td><?php echo e($tabel->jurusan); ?></td>
							<td>
								<form action="#" method="POST">
									<a class="btn btn-sm btn-waring" href="<?php echo e(route('tabel.edit')); ?>">Edit</a>
									<a class="btn btn-sm btn-danger" href="<?php echo e(route('tabel.delete')); ?>">Delete</a>
								</form>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					</table>
					
				</div>
			</div>
		</div>
	</div>
</body>
</html>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\RPL XII-3\ppdb\resources\views/tabel/index.blade.php ENDPATH**/ ?>