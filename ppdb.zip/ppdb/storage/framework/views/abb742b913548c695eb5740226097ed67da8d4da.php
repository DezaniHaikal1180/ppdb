<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<body>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <div class="pull-right">
                    <a class="btn btn-primary" href="<?php echo e(route('siswa.create')); ?>">+</a>
                </div>
            </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
 
 
            <div class="card-body">
                <table class="table">
                <thead>
                                <tr>
                                <th class="col">nis</th>
								<th class="col">nama</th>
								<th class="col">jns kelamin</th>
								<th class="col">temp lahir</th>
								<th class="col">tgl lahir</th>
								<th class="col">alamat</th>
								<th class="col">asal sekolah</th>
								<th class="col">kelas</th>
								<th class="col">jurusan</th>
                                  <th scope="col">Action</th>
                              </tr>
                          </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                        <td><?php echo e($siswa->nis); ?></td>
                        <td><?php echo e($siswa->nama); ?></td>
                        <td><?php echo e($siswa->jns_kelamin); ?></td>
                        <td><?php echo e($siswa->temp_lahir); ?></td>
                        <td><?php echo e($siswa->tgl_lahir); ?></td>
                        <td><?php echo e($siswa->alamat); ?></td>
                        <td><?php echo e($siswa->asal_sekolah); ?></td>
                        <td><?php echo e($siswa->kelas); ?></td>
                        <td><?php echo e($siswa->jurusan); ?></td>
                        <td>
                            <form action="#" method="POST">
 
                               
 
                                <a class="btn btn-sm btn-primary" href="<?php echo e(route ('siswa.edit',$siswa->id)); ?>">Edit</a>
                                <a class="btn btn-sm btn-success" href="<?php echo e(route ('siswa.show',$siswa->id)); ?>">show</a>
                                <a  class="btn btn-sm btn-danger" href="<?php echo e(route('siswa.destroy', $siswa->id)); ?>" class="badge badge-danger">Delete</a>
                                <a class="btn btn-sm btn-primary" href="<?php echo e(route ('siswa.clear')); ?>">clear</a>

                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\RPL XII-3\ppdb\resources\views/siswa/index.blade.php ENDPATH**/ ?>