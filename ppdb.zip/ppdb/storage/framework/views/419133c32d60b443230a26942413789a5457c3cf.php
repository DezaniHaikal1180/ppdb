<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<body>
<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            Input Kendaraan<small><code></code></small>
           
        </div>
        <form action="<?php echo e(route('siswa.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
        <div class="card-body card-block">
            <form action="" method="post" class="form-horizontal">
                <div class="form-group">
                    <div class="col-6">
                        <label for="nis" class="form-control-label" >ID Petugas</label>
                        <input type="number" name="nis" id="nis" placeholder="id petugas" class="form-control">
                    </div>
                    <div class="col-6">
                        <label for="nama" class="form-control-label">nama</label><input name="nama" id="nama" type="text" placeholder="Masukan Nama Barang" class="form-control">
                    </div>
                </div>
                <div class="row form-group">
                        <label for="jns_kelamin" class="form-control-label">Jenis Kelamin</label>
                        <select name="jns_kelamin" id="jns_kelamin" type="text" class="form-control" >
                            <option>jenis kelamin</option>
                            <option value="laki-laki">laki-laki</option>
                            <option value="perempuan">perempuan</option>
                        </select>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-6">
                        <label for="temp_lahir" class="form-control-label">temp_lahir</label><input name="temp_lahir" id="temp_lahir" type="text" class="form-control">
                    </div>
                    <div class="col-6">
                        <label for="tgl_lahir" class="form-control-label">tgl_lahir</label><input name="tgl_lahir" id="tgl_lahir" type="date" class="form-control">
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-6">
                        <label for="alamat" class="form-control-label">alamat</label><input name="alamat" id="alamat" type="text" class="form-control">
                    </div>
                    <div class="col-6">
                        <label for="asal_sekolah" class="form-control-label">asal_sekolah</label><input name="asal_sekolah" id="asal_sekolah" type="text" class="form-control">
                    </div>
                </div>
                <div class="row form-group">
                <div class="col-6">
                        <label for="kelas" class="form-control-label">kelas</label><input name="kelas" id="kelas" type="text" class="form-control">
                </div>
                <div class="col-6">
                        <label for="jurusan" class="form-control-label">jurusan</label><input name="jurusan" id="jurusan" type="text" class="form-control">
                </div>
            </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-sm">Submit</button> 
                    <a class="btn btn-success" href="<?php echo e(route ('siswa.index')); ?>">Back</a>
                </div>
            </form>
            <form action="<?php echo e(route('siswa.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
                
        </form>
        </div>
    </div>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\RPL XII-3\ppdb\resources\views/siswa/create.blade.php ENDPATH**/ ?>