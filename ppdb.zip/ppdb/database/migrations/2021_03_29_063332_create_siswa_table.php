<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSiswaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('siswa', function (Blueprint $table) {
            $table->id();
            $table->String('nis');
            $table->String('nama');
            $table->String('jns_kelamin');
            $table->String('temp_lahir');
            $table->String('tgl_lahir');
            $table->String('alamat');
            $table->String('asal_sekolah');
            $table->String('kelas');
            $table->String('jurusan');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('siswa');
    }
}
